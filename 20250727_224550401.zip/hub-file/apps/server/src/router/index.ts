import userRouter from "./user.ts";
import fileRouter from "./file.ts";
import ossRouter from "./oss.ts";
import rootRouter from "./root.ts";
import combineRouters from "koa-combine-routers";
import latexRouter from "./latex.ts";
import mathjaxRouter from "./mathjax.ts";

const router = combineRouters(
  // @ts-ignore
  rootRouter,
  userRouter,
  fileRouter,
  ossRouter,
  latexRouter,
  mathjaxRouter
);

export default router;
