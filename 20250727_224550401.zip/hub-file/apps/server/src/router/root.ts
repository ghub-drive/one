import Router from '@koa/router';
import JsonResult from '../utils/json-result';

const router = new Router({ prefix: '/' });
router.get('/', async (ctx, next) => {
  ctx.body = 'Hello';
});

// 登录
router.post('/login', async (ctx, next) => {
  ctx.body = JsonResult.failed('暂未注册，请先注册！');
});

// 文件上传

export default router;
