import qiniu from "qiniu";
import path from "path";
import fs from "fs";
import qiniuHelper from "../utils/qiniu-helper";

export const upload = async (file) => {
  // 获取文件信息
  const { originalFilename, filepath } = file; // 新版可能是 `filepath` 而不是 `path`

  const reader = fs.createReadStream(filepath);
  const filePath = path.join(originalFilename);
  const upToken = qiniuHelper.getUploadToken();

  const config = new qiniu.conf.Config();
  const formUploader = new qiniu.form_up.FormUploader(config);
  const putExtra = new qiniu.form_up.PutExtra();

  return new Promise((resolve, reject) => {
    formUploader.putStream(
      upToken,
      filePath,
      reader,
      putExtra,
      (respErr, respBody, respInfo) => {
        if (respErr) {
          reject(respErr);
        }
        if (respInfo.statusCode === 200) {
          resolve(`${qiniuHelper.domain}/${respBody.key}`);
        } else {
          reject(respBody.error);
        }
      }
    );
  });
};
