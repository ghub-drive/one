// mathjax-svg.js
import { mathjax } from "mathjax-full/js/mathjax.js";
import { TeX } from "mathjax-full/js/input/tex.js";
import { SVG } from "mathjax-full/js/output/svg.js";
import { liteAdaptor } from "mathjax-full/js/adaptors/liteAdaptor.js";
import { RegisterHTMLHandler } from "mathjax-full/js/handlers/html.js";
import { AllPackages } from "mathjax-full/js/input/tex/AllPackages.js";
import { JSDOM } from "jsdom";

// 初始化一次
const adaptor = liteAdaptor();
RegisterHTMLHandler(adaptor);

const tex = new TeX({ packages: AllPackages });
const svg = new SVG({ fontCache: "local" });

const html = mathjax.document("", {
  InputJax: tex,
  OutputJax: svg,
});

const genErrSvg = (errorMessage: string) => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="80" viewBox="0 0 300 80">
  <defs>
    <linearGradient id="errorGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#ff6b6b;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#ee5a52;stop-opacity:1" />
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.3"/>
    </filter>
  </defs>
  
  <!-- 背景圆角矩形 -->
  <rect x="10" y="10" width="280" height="60" rx="8" ry="8" 
        fill="url(#errorGradient)" stroke="#d63031" stroke-width="2" filter="url(#shadow)"/>
  
  <!-- 错误图标 -->
  <circle cx="35" cy="40" r="12" fill="#ffffff" opacity="0.9"/>
  <text x="35" y="45" text-anchor="middle" font-family="Arial, sans-serif" 
        font-size="16" font-weight="bold" fill="#d63031">!</text>
  
  <!-- 错误文本 -->
  <text x="60" y="30" font-family="Arial, sans-serif" font-size="12" 
        font-weight="bold" fill="#ffffff">LaTeX 渲染错误</text>
  <text x="60" y="45" font-family="Arial, sans-serif" font-size="10" 
        fill="#ffffff" opacity="0.9">${errorMessage}</text>
</svg>`;
  return svg;
};

const genErrSvg2 = (errorMessage: string) => {
  // 估算文本宽度和高度
  const textWidth = errorMessage.length * 8;
  const textHeight = 18; // 字体大小

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${textWidth}" height="${textHeight}" viewBox="0 0 ${textWidth} ${textHeight}">
  <text x="0" y="14" font-family="Arial, sans-serif" font-size="18" fill="#666">${errorMessage}</text>
</svg>`;
};

/**
 * 将 LaTeX 表达式渲染为 SVG 字符串
 * @param {string} latex - LaTeX 数学表达式
 * @param {boolean} [display=true] - 是否作为块级公式显示
 * @returns {Promise<string>} 渲染后的 SVG 字符串
 */
export async function renderMathToSVG(latex, display = true) {
  try {
    // 基本输入检查
    if (!latex || typeof latex !== "string") {
      throw new Error("LaTeX 表达式不能为空且必须是字符串");
    }

    // 让 MathJax 自己处理 LaTeX 语法错误
    const node = html.convert(latex, { display });
    const svgOutput = adaptor.outerHTML(node);

    // 检查 MathJax 是否检测到错误
    if (svgOutput.includes("data-mjx-error=") || svgOutput.includes("merror")) {
      // 提取错误信息
      const errorMatch = svgOutput.match(/data-mjx-error="([^"]+)"/);
      const errorMessage = errorMatch ? errorMatch[1] : "LaTeX 语法错误";
      // throw new Error(errorMessage);
      return genErrSvg2(latex);
    }

    // 提取纯 SVG 内容，移除 mjx-container 包装
    const svgMatch = svgOutput.match(/<svg[^>]*>[\s\S]*?<\/svg>/);
    if (svgMatch) {
      return svgMatch[0];
    }

    return svgOutput;
  } catch (error) {
    // 构建一个美观的错误 SVG
    const errorMessage = error.message.replace("MathJax 渲染错误: ", "");
    // throw new Error(errorMessage);
    return genErrSvg2(latex);
  }
}


/**
 * 将 LaTeX 表达式渲染为 SVG 字符串
 * @param {string} latex - LaTeX 数学表达式
 * @param {boolean} [display=true] - 是否作为块级公式显示
 * @returns {Promise<string>} 渲染后的 SVG 字符串
 */
export async function renderMathToSVGPlus(htmlStr, display = true) {
  const dom = new JSDOM(`<!DOCTYPE html>${htmlStr}`);
  const latexContainers = dom.window.document.querySelectorAll('[data-math]');
  for (const container of latexContainers) {
    const latex = container.getAttribute('data-math');
    if (latex) {
      const svg = await renderMathToSVG(latex, display);
      container.innerHTML = svg;
    }
  }
  return dom.window.document.body.innerHTML;
}


export async function render(
  type: "latex" | "html",
  content: string,
  display = true
) {
  if(type === 'latex'){
    return await renderMathToSVG(content, display);
  }else{
    return await renderMathToSVGPlus(content, display);
  }
}