import type { Component } from 'solid-js';
import routes from './router';
import { Router } from '@solidjs/router';

const App: Component = () => {
  return (
    <div>
      <Router>{routes}</Router>
    </div>
  );
};

export default App;
