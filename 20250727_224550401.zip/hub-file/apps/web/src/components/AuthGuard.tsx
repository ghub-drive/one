import { createEffect, JSX } from 'solid-js';
import { useNavigate } from '@solidjs/router';
import { isAuthenticated } from '../utils/auth';

interface AuthGuardProps {
  children: JSX.Element;
}

const AuthGuard = (props: AuthGuardProps) => {
  const navigate = useNavigate();

  createEffect(() => {
    if (!isAuthenticated()) {
      navigate('/auth');
    }
  });

  // 如果已认证，显示子组件
  if (isAuthenticated()) {
    return <>{props.children}</>;
  }

  // 未认证时显示空内容（会被重定向）
  return null;
};

export default AuthGuard;