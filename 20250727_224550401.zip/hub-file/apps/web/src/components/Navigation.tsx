import { A } from '@solidjs/router';
import { createSignal } from 'solid-js';

const Navigation = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = createSignal(false);

  return (
    <nav class="bg-white shadow-sm border-b border-gray-200">
      <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between items-center h-16">
          <div class="flex items-center space-x-2">
            <i class="ri-folder-settings-fill text-2xl text-blue-600"></i>
            <h1 class="text-lg sm:text-xl font-bold text-gray-900">文件管理系统</h1>
          </div>
          
          {/* 桌面端导航 */}
          <div class="hidden md:flex space-x-4">
            <A
              href="/file-upload"
              class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              activeClass="bg-blue-100 text-blue-700"
              inactiveClass="text-gray-600 hover:text-gray-900 hover:bg-gray-50"
            >
              <i class="ri-upload-cloud-2-line"></i>
              <span>文件上传</span>
            </A>
            <A
              href="/file-mgt"
              class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              activeClass="bg-blue-100 text-blue-700"
              inactiveClass="text-gray-600 hover:text-gray-900 hover:bg-gray-50"
            >
              <i class="ri-folder-open-line"></i>
              <span>文件浏览器</span>
            </A>
          </div>

          {/* 移动端菜单按钮 */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen())}
            class="md:hidden p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-50"
          >
            <i class={`text-xl ${mobileMenuOpen() ? 'ri-close-line' : 'ri-menu-line'}`}></i>
          </button>
        </div>

        {/* 移动端下拉菜单 */}
        {mobileMenuOpen() && (
          <div class="md:hidden border-t border-gray-200 py-2">
            <A
              href="/file-upload"
              class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              activeClass="bg-blue-100 text-blue-700"
              inactiveClass="text-gray-600 hover:text-gray-900 hover:bg-gray-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              <i class="ri-upload-cloud-2-line"></i>
              <span>文件上传</span>
            </A>
            <A
              href="/file-mgt"
              class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              activeClass="bg-blue-100 text-blue-700"
              inactiveClass="text-gray-600 hover:text-gray-900 hover:bg-gray-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              <i class="ri-folder-open-line"></i>
              <span>文件浏览器</span>
            </A>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
