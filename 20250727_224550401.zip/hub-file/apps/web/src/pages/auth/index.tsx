import { createSignal } from 'solid-js';
import { useNavigate } from '@solidjs/router';

const Auth = () => {
  const navigate = useNavigate();
  const [code, setCode] = createSignal('');
  const [sending, setSending] = createSignal(false);
  const [verifying, setVerifying] = createSignal(false);
  const [message, setMessage] = createSignal('');
  const [codeSent, setCodeSent] = createSignal(false);

  // 管理员邮箱（写死在代码中）
  const ADMIN_EMAIL = 'admin@example.com';

  // 发送验证码
  const sendCode = async () => {
    setSending(true);
    setMessage('');
    
    try {
      const response = await fetch('http://localhost:3002/auth/send-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: ADMIN_EMAIL }),
      });

      const result = await response.json();
      if (result.code === 0) {
        setCodeSent(true);
        setMessage('验证码已发送到管理员邮箱');
      } else {
        setMessage(`发送失败: ${result.msg}`);
      }
    } catch (error) {
      setMessage('发送验证码失败，请稍后重试');
    } finally {
      setSending(false);
    }
  };

  // 验证验证码
  const verifyCode = async () => {
    if (!code().trim()) {
      setMessage('请输入验证码');
      return;
    }

    setVerifying(true);
    setMessage('');

    try {
      const response = await fetch('http://localhost:3002/auth/verify-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email: ADMIN_EMAIL,
          code: code().trim()
        }),
      });

      const result = await response.json();
      if (result.code === 0) {
        // 验证成功，存储到会话存储
        sessionStorage.setItem('auth_token', result.data.token);
        sessionStorage.setItem('auth_time', Date.now().toString());
        
        setMessage('验证成功，正在跳转...');
        setTimeout(() => {
          navigate('/file-upload');
        }, 1000);
      } else {
        setMessage(`验证失败: ${result.msg}`);
      }
    } catch (error) {
      setMessage('验证失败，请稍后重试');
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div class="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div class="max-w-md w-full bg-white rounded-lg shadow-md p-8">
        <div class="text-center mb-8">
          <i class="ri-shield-check-line text-4xl text-blue-600 mb-4"></i>
          <h1 class="text-2xl font-bold text-gray-900">身份验证</h1>
          <p class="text-gray-600 mt-2">请验证身份以访问文件管理系统</p>
        </div>

        <div class="space-y-6">
          {/* 管理员邮箱显示 */}
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">
              管理员邮箱
            </label>
            <div class="flex items-center px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
              <i class="ri-mail-line text-gray-400 mr-2"></i>
              <span class="text-gray-600">{ADMIN_EMAIL}</span>
            </div>
          </div>

          {/* 发送验证码按钮 */}
          {!codeSent() && (
            <button
              onClick={sendCode}
              disabled={sending()}
              class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {sending() ? (
                <>
                  <i class="ri-loader-4-line animate-spin mr-2"></i>
                  发送中...
                </>
              ) : (
                <>
                  <i class="ri-send-plane-line mr-2"></i>
                  发送验证码
                </>
              )}
            </button>
          )}

          {/* 验证码输入 */}
          {codeSent() && (
            <>
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  验证码
                </label>
                <input
                  type="text"
                  value={code()}
                  onInput={(e) => setCode(e.target.value)}
                  placeholder="请输入6位验证码"
                  maxLength={6}
                  class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-center text-lg tracking-widest"
                />
              </div>

              <div class="flex space-x-3">
                <button
                  onClick={verifyCode}
                  disabled={verifying() || !code().trim()}
                  class="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                >
                  {verifying() ? (
                    <>
                      <i class="ri-loader-4-line animate-spin mr-2"></i>
                      验证中...
                    </>
                  ) : (
                    <>
                      <i class="ri-check-line mr-2"></i>
                      验证
                    </>
                  )}
                </button>

                <button
                  onClick={sendCode}
                  disabled={sending()}
                  class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:bg-gray-100 disabled:cursor-not-allowed transition-colors"
                >
                  重发
                </button>
              </div>
            </>
          )}

          {/* 消息提示 */}
          {message() && (
            <div class={`p-3 rounded-lg text-sm ${
              message().includes('成功') || message().includes('已发送')
                ? 'bg-green-50 text-green-800 border border-green-200'
                : 'bg-red-50 text-red-800 border border-red-200'
            }`}>
              <div class="flex items-center">
                <i class={`mr-2 ${
                  message().includes('成功') || message().includes('已发送')
                    ? 'ri-check-circle-line'
                    : 'ri-error-warning-line'
                }`}></i>
                {message()}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auth;