import { createSignal, onMount } from 'solid-js';
import Navigation from '../../components/Navigation';
import AuthGuard from '../../components/AuthGuard';

const FileUpload = () => {
  const [selectedFile, setSelectedFile] = createSignal<File | null>(null);
  const [uploading, setUploading] = createSignal(false);
  const [uploadResult, setUploadResult] = createSignal<string>('');
  const [selectedDir, setSelectedDir] = createSignal<string>('/');
  
  // 目录树相关状态
  const [directoryTree, setDirectoryTree] = createSignal<any>(null);
  const [loadingDirs, setLoadingDirs] = createSignal(false);
  const [expandedNodes, setExpandedNodes] = createSignal<Set<string>>(new Set([''])); // 默认展开根目录
  const [showDirectoryTree, setShowDirectoryTree] = createSignal(false);

  // 获取目录树
  const fetchDirectories = async () => {
    setLoadingDirs(true);
    try {
      const response = await fetch('http://localhost:3002/file/dir-tree');
      const result = await response.json();
      if (result.code === 0) {
        setDirectoryTree(result.data);
      }
    } catch (error) {
      console.error('获取目录失败:', error);
    } finally {
      setLoadingDirs(false);
    }
  };

  onMount(() => {
    fetchDirectories();
  });

  // 切换节点展开状态
  const toggleNode = (path: string) => {
    const expanded = expandedNodes();
    const newExpanded = new Set(expanded);
    if (expanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedNodes(newExpanded);
  };

  // 选择目录
  const selectDirectory = (path: string, name: string) => {
    setSelectedDir(path === '' ? '/' : path);
    setShowDirectoryTree(false);
  };

  // 获取当前选中目录的显示名称
  const getSelectedDirName = () => {
    if (selectedDir() === '/') return '根目录';
    return selectedDir();
  };

  // 渲染目录树节点
  const renderTreeNode = (node: any, level = 0) => {
    const isExpanded = expandedNodes().has(node.path);
    const isSelected = (selectedDir() === '/' && node.path === '') || selectedDir() === node.path;
    const hasChildren = node.children && node.children.length > 0;

    return (
      <div>
        <div 
          class={`flex items-center py-2 px-3 rounded cursor-pointer hover:bg-gray-100 ${
            isSelected ? 'bg-blue-100 text-blue-700' : ''
          }`}
          style={`padding-left: ${level * 20 + 12}px`}
          onClick={() => selectDirectory(node.path, node.name)}
        >
          {hasChildren && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleNode(node.path);
              }}
              class="mr-2 p-1 hover:bg-gray-200 rounded"
            >
              <svg 
                class={`w-3 h-3 transition-transform ${isExpanded ? 'rotate-90' : ''}`} 
                fill="currentColor" 
                viewBox="0 0 20 20"
              >
                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
              </svg>
            </button>
          )}
          {!hasChildren && <div class="w-7"></div>}
          <svg class="w-4 h-4 text-yellow-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4l2 2h4a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" />
          </svg>
          <span class="text-sm">{node.name}</span>
        </div>
        {hasChildren && isExpanded && (
          <div>
            {node.children.map(child => renderTreeNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  const handleFileSelect = (event: Event) => {
    const target = event.target as HTMLInputElement;
    const file = target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setUploadResult('');
    }
  };

  const handleUpload = async () => {
    const file = selectedFile();
    const dir = selectedDir();
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      // 如果选择的是根目录，传递空字符串
      formData.append('directory', dir === '/' ? '' : dir);

      const response = await fetch('http://localhost:3002/file/upload', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();
      if (result.code === 0) {
        setUploadResult(`上传成功！文件地址: ${result.data}`);
        setSelectedFile(null);
        const fileInput = document.getElementById('file-input') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
      } else {
        setUploadResult(`上传失败: ${result.msg}`);
      }
    } catch (error) {
      setUploadResult('上传出错');
    } finally {
      setUploading(false);
    }
  };

  return (
    <AuthGuard>
      <div class="min-h-screen bg-gray-50">
        <Navigation />
        <div class="py-8">
          <div class="max-w-4xl mx-auto px-4">
            
            <div class="bg-white rounded-lg shadow-md p-6">
              {/* 目录选择 */}
              <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  选择目录
                </label>
                {loadingDirs() ? (
                  <div class="text-gray-500">加载目录中...</div>
                ) : (
                  <div class="relative">
                    {/* 目录选择按钮 */}
                    <button
                      onClick={() => setShowDirectoryTree(!showDirectoryTree())}
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-left flex items-center justify-between"
                    >
                      <div class="flex items-center">
                        <svg class="w-4 h-4 text-yellow-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                          <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4l2 2h4a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" />
                        </svg>
                        <span>{getSelectedDirName()}</span>
                      </div>
                      <svg 
                        class={`w-4 h-4 transition-transform ${showDirectoryTree() ? 'rotate-180' : ''}`} 
                        fill="currentColor" 
                        viewBox="0 0 20 20"
                      >
                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                      </svg>
                    </button>

                    {/* 目录树下拉面板 */}
                    {showDirectoryTree() && (
                      <div class="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-64 overflow-y-auto">
                        {directoryTree() ? (
                          <div class="py-2">
                            {renderTreeNode(directoryTree())}
                          </div>
                        ) : (
                          <div class="p-4 text-center text-gray-500">无可用目录</div>
                        )}
                      </div>
                    )}

                    {/* 点击外部关闭下拉面板 */}
                    {showDirectoryTree() && (
                      <div 
                        class="fixed inset-0 z-0" 
                        onClick={() => setShowDirectoryTree(false)}
                      ></div>
                    )}
                  </div>
                )}
              </div>

              {/* 文件选择 */}
              <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  选择文件
                </label>
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                  <input
                    id="file-input"
                    type="file"
                    onChange={handleFileSelect}
                    class="hidden"
                  />
                  <label
                    for="file-input"
                    class="cursor-pointer flex flex-col items-center"
                  >
                    <svg class="w-12 h-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span class="text-gray-600">点击选择文件或拖拽文件到此处</span>
                    <span class="text-sm text-gray-400 mt-1">支持所有文件格式</span>
                  </label>
                </div>
              </div>

              {/* 文件信息 */}
              {selectedFile() && (
                <div class="mb-6 p-4 bg-blue-50 rounded-lg">
                  <h3 class="font-medium text-blue-900 mb-2">已选择文件:</h3>
                  <div class="text-sm text-blue-700">
                    <p>文件名: {selectedFile()!.name}</p>
                    <p>大小: {(selectedFile()!.size / 1024 / 1024).toFixed(2)} MB</p>
                    <p>类型: {selectedFile()!.type || '未知'}</p>
                    <p>上传到: {getSelectedDirName()}</p>
                  </div>
                </div>
              )}

              {/* 操作按钮 */}
              <div class="flex gap-4">
                <button
                  onClick={handleUpload}
                  disabled={!selectedFile() || !selectedDir() || uploading()}
                  class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  {uploading() ? '上传中...' : '上传文件'}
                </button>
                
                <button
                  onClick={() => {
                    setSelectedFile(null);
                    setUploadResult('');
                    const fileInput = document.getElementById('file-input') as HTMLInputElement;
                    if (fileInput) fileInput.value = '';
                  }}
                  class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  清除
                </button>
              </div>

              {/* 上传结果 */}
              {uploadResult() && (
                <div class={`mt-4 p-4 rounded-lg ${
                  uploadResult().includes('成功') 
                    ? 'bg-green-50 text-green-800 border border-green-200' 
                    : 'bg-red-50 text-red-800 border border-red-200'
                }`}>
                  {uploadResult()}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AuthGuard>
  );
};

export default FileUpload;
