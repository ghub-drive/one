import { createEffect } from 'solid-js';
import { useNavigate } from '@solidjs/router';
import { isAuthenticated } from '../../utils/auth';

const Home = () => {
  const navigate = useNavigate();

  createEffect(() => {
    if (isAuthenticated()) {
      navigate('/file-upload');
    } else {
      navigate('/auth');
    }
  });

  return (
    <div class="min-h-screen bg-gray-50 flex items-center justify-center">
      <div class="text-center">
        <i class="ri-loader-4-line animate-spin text-4xl text-blue-600 mb-4"></i>
        <p class="text-gray-600">正在检查认证状态...</p>
      </div>
    </div>
  );
};

export default Home;
