import { lazy } from "solid-js";

const routes = [
  {
    path: "/",
    component: lazy(() => import("../pages/home")),
  },
  {
    path: "/auth",
    component: lazy(() => import("../pages/auth")),
  },
  {
    path: "/file-upload",
    component: lazy(() => import("../pages/file-upload")),
  },
  {
    path: "/file-mgt",
    component: lazy(() => import("../pages/file-mgt")),
  },
];

export default routes;
