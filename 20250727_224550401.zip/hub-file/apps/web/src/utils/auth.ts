// 检查是否已认证
export const isAuthenticated = (): boolean => {
  const token = sessionStorage.getItem('auth_token');
  const authTime = sessionStorage.getItem('auth_time');
  
  if (!token || !authTime) {
    return false;
  }
  
  // 检查是否过期（24小时）
  const now = Date.now();
  const authTimestamp = parseInt(authTime);
  const EXPIRE_TIME = 24 * 60 * 60 * 1000; // 24小时
  
  if (now - authTimestamp > EXPIRE_TIME) {
    // 过期，清除存储
    sessionStorage.removeItem('auth_token');
    sessionStorage.removeItem('auth_time');
    return false;
  }
  
  return true;
};

// 清除认证信息
export const clearAuth = (): void => {
  sessionStorage.removeItem('auth_token');
  sessionStorage.removeItem('auth_time');
};